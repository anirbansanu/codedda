<?php
$zip = new ZipArchive;
if ($zip->open('test_folder.zip', ZipArchive::CREATE) === TRUE)
{
    // Add files to the zip file inside demo_folder
    $zip->addFile('text.txt', 'demo_folder/test.txt');
    $zip->addFile('test.pdf', 'demo_folder/test.pdf');
 
    // Add random.txt file to zip and rename it to newfile.txt and store in demo_folder
    $zip->addFile('random.txt', 'demo_folder/newfile.txt');
 
    // Add a file demo_folder/new.txt file to zip using the text specified
    $zip->addFromString('demo_folder/new.txt', 'text to be added to the new.txt file');
 
    // All files are added, so close the zip file.
    $zip->close();
}
?>