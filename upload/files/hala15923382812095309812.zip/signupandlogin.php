
<!DOCTYPE html>
<html>
<head>
  <title>Sign-Up/Login Form</title>
  
</head>


<body>
<style>
a {
  text-decoration: none;
  color: #fff;
  -webkit-transition: .5s ease;
  transition: .5s ease;
}
a:hover {
  color: red;
}

.form {
  background: linear-gradient(to bottom right, #a98e63, #73301f,#a98e63, #702d1a); 
  padding: 40px;
  max-width: 600px;
  margin: 40px auto;
  border-radius: 4px;
  box-shadow: 0 8px 13px 8px rgba(19, 35, 47, 0.3);
  opacity: 0.8;
  filter: alpha(opacity=100);
}

.tab-group {
  list-style: none;
  padding: 0;
  margin: 0 0 40px 0;
}
.tab-group:after {
  content: "";
  display: table;
  clear: both;
}
.tab-group li a {
  display: block;
  text-decoration: none;
  padding: 15px;
  background: #73301f;
  color: #fff;
  font-size: 20px;
  float: left;
  width: 44.55%;
  text-align: center;
  cursor: pointer;
  -webkit-transition: .5s ease;
  transition: .5s ease;
}
.tab-group li a:hover {
  background: #fff;
  color: #000;
}
.tab-group .active a {
  background: red;
  color: #ffffff;
}

.tab-content > div:last-child {
  display: none;
}

h1 {
  text-align: center;
  color: #fff;
  font-weight: 300;
  margin: 0 0 40px;
}

<!----h2 {
    text-align: center;
    color: #1ab188;
    font-weight: 1000;
    margin: 0;
}---->

span {
    color: #1ab188;
    font-weight: bold;
}

p {
    text-align: center;
    color: #fff;
    margin: 0px 0px 50px 0px;
}

div.info {
    color: pink;
    display: box;
    text-align: center;
    padding: 5px;
    margin-top: -20px;
    margin-bottom: 15px;
    border: 1px solid red;
    background: #66131c;
}

label {
  position: absolute;
  -webkit-transform: translateY(6px);
          transform: translateY(6px);
  left: 13px;
  color: #000;
  -webkit-transition: all 0.25s ease;
  transition: all 0.25s ease;
  -webkit-backface-visibility: hidden;
  pointer-events: none;
  font-size: 22px;
}
label .req {
  margin: 10px;
  color: red;
}

label.active {
  -webkit-transform: translateY(50px);
          transform: translateY(50px);
  left: 2px;
  font-size: 14px;
  color: #fff;
}
label.active .req {
  opacity: 0;
}

label.highlight {
  color: #ffffff;
}
input { 
    display: block;
	width: 100%; 
	height: 100%;
	margin-bottom: 10px; 
	background:#a98e63;
	border: none;
	outline: none;
	padding: 8px 10px;
	font-size: 22px;
	font-weight: bold;
	color: #fff;
	border: 2px solid #692a19;
	border-radius: 22px;
	box-shadow: inset 0 -5px 45px rgba(100,100,100,0.2), 0 1px 1px rgba(255,255,255,0.2);
	opacity: 1
  filter: alpha(opacity=100);
  -webkit-transition: border-color .25s ease, box-shadow .25s ease;
  transition: border-color .25s ease, box-shadow .25s ease;
}
 textarea {
  font-size: 22px;
  display: block;
  width: 100%;
  height: 100%;
  padding: 5px 10px;
  background: none;
  background-image: none;
  border: 1px solid #a0b3b0;
  color: #ffffff;
  border-radius: 0;
  -webkit-transition: border-color .25s ease, box-shadow .25s ease;
  transition: border-color .25s ease, box-shadow .25s ease;
}
input:focus, textarea:focus {
  outline: 0;
  background: #fff;
  border-color: red;
  color: #222;
}

textarea {
  border: 2px solid #a0b3b0;
  resize: vertical;
}

.field-wrap {
  position: relative;
  margin-bottom: 40px;
}

.top-row:after {
  content: "";
  display: table;
  clear: both;
}
.top-row > div {
  float: left;
  width: 48%;
  margin-right: 4%;
}
.top-row > div:last-child {
  margin: 0;
}

.button {
  border: 0;
  outline: none;
  border-radius: 27px;
  border: 13px;
  border-color: #fff;
  padding: 13px 3px;
  font-size: 2rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: .1em;
  background: #73301f;
  color: #ffffff;
  -webkit-transition: all 0.5s ease;
  transition: all 0.5s ease;
  -webkit-appearance: none;
}
.button:hover, .button:focus {
  background: red;
  border-radius: 55px;
  width: 46%;
}

.button-block {
  display: block;
  width: 50%;
}

.forgot {
  margin-top: -20px;
  text-align: right;
  
}



</style>
<div class="page">
<?php include 'E:\xwamp\htdocs\ani\include\menus\index.php';?>
<div class="main-content">

   <?php include 'E:\xwamp\htdocs\ani\include\sidemenu\menu.php';?>
 

  <div class="form">
      
      <ul class="tab-group">
        <li class="tab"><a href="#signup"><b>Sign Up</b></a></li>
        <li class="tab active"><a href="#login"><b>Log In</b></a></li>
      </ul>
      
      <div class="tab-content">

         <div id="login">   
          <h1>Welcome Back!</h1>
          
          <form action="login.php" method="post" autocomplete="off">
          
            <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email" required autocomplete="off" name="email"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input type="password" required autocomplete="off" name="password"/>
          </div>
          
          <p class="forgot"><a href="forgot.php">Forgot Password?</a></p>
          
          <button class="button button-block" name="login" />Log In</button>
          
          </form>

        </div>
          
        <div id="signup">   
          <h1>Sign Up</h1>
          
          <form action="signup.php" method="post" autocomplete="off">
          
          <div class="top-row">
            <div class="field-wrap">
              <label>
                First Name<span class="req">*</span>
              </label>
              <input type="text" required autocomplete="off" name='firstname' />
            </div>
        
            <div class="field-wrap">
              <label>
                Last Name<span class="req">*</span>
              </label>
              <input type="text" required autocomplete="off" name='lastname' />
            </div>
          </div>

          <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email"required autocomplete="off" name='email' />
          </div>
          
          <div class="field-wrap">
            <label>
              Set A Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off" name='password'/>
          </div>
          
          <button type="submit" class="button button-block" name="register" />Register</button>
          
          </form>

        </div>  
        
      </div><!-- tab-content -->
      
</div> <!-- /form -->
 <br/><br/>
<?php include 'E:\xwamp\htdocs\ani\footerframe\footer.php';?>
</div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>



  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
