<?php
ob_start();
include "db.php";
?>
<?php
if(isset($_POST['register']))
 {
	  
$fname = $_POST["firstname"];
$lname = $_POST["lastname"];
$email = $_POST["email"];
$pass = $_POST["password"];
$sql1 = "select `email` from `adminuser` WHERE `email`='$email'";

$result = mysqli_query($conn,$sql1); 
if(mysqli_affected_rows($conn))
  {   
      header('Location: http://localhost/ani/admin/signupandlogin.php?error=Error: email is already exists');
      
  }
  else
  {
	  $sql = "insert into `adminuser`(`fname`,`lname`, `email`, `pass`) values('$fname','$lname', '$email', '$pass' )";
      $result = mysqli_query($conn,$sql);
      if(mysqli_affected_rows($conn))
      {
    	header('Location:http://localhost/ani/admin/signupandlogin.php?success=Success: successfully registered');
      }
      else
      {
	header('Location: http://localhost/ani/admin/signupandlogin.php?error=Error: please do properly');
      }
  }
}
else
 {
	header('Location: http://localhost/ani/admin/signupandlogin.php?error=Error: please enter values first');
 }



?>
