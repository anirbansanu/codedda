<?php
ob_start();
include "db.php";
?>
<?php
 session_start();
if(isset($_POST['login']))
{
//echo "Congratulation!! your selected data is selected.<br>";
//$sql = "select * from `user_table` ";
$email = $_POST["email"];
$pass = $_POST["password"];
$sql = "select * from `adminuser` WHERE `email`='$email' && `pass`='$pass' ";

$result = mysqli_query($conn,$sql); 
if(mysqli_affected_rows($conn))
  {   
      
      $data = mysqli_fetch_assoc($result);
	  if(strtoupper($data['email'])!=strtoupper($email) and strtoupper($data['pass'])!=strtoupper($pass))
			{
				header('Location: http://localhost/ani/admin/signupandlogin.php?error=Error: email and password are not matched');     
			}
			elseif(strtoupper($data['email'])==strtoupper($email) and strtoupper($data['pass'])==strtoupper($pass))
			{
				$_SESSION['email']=$data['email'];
				$_SESSION['fname']=$data['fname'];
			 header('Location:http://localhost/ani/stu_reg_form/index.php?success=Success: successfully loged in '.$_SESSION["fname"].'');
			}
	 
  }
  else
  {
	  header('Location: http://localhost/ani/admin/signupandlogin.php?error=Error: email and password are not matched');
  }
}
else
{
	header('Location: http://localhost/ani/admin/signupandlogin.php?error=Error: login first');
}
	?>