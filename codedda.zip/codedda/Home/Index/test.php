<!DOCTYPE html>
<header>
</header>
<body class="">
    <div class="form-group">
      <label for=""></label>
      <input type="text" name="" id="" class="form-control" placeholder="" aria-describedby="helpId">
      <small id="helpId" class="text-muted">Help text</small>
    </div>
</body>
</html>