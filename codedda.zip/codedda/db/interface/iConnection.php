<?php
interface iConnection {
	public function dbCon();
	public function close();
}




?>