<?php
interface iFilesToZip
{
	public function fTZ($set_File_Name="", $files=NULL, $file_Directory="", $btn_Name=null);

}
?>