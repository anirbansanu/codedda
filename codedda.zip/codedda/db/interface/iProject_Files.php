<?php
interface iProject_Files
{
	public function submit($id,$files,$set_name="",$submit_btn);
}
?>