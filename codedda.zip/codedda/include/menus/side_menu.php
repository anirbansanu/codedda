	<!-- Main Sidebar Container -->
	<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="../../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Collab</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../../dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Ani</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="http://localhost/AdminLTE-3.0.4/home/Index/" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Projects
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="http://localhost/AdminLTE-3.0.4/Projects/create/create.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Project Add</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../Projects/update/update.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Project Edit</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../Projects/list/list.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Project List</p>
                </a>
              </li>
			  <li class="nav-item">
                <a href="http://localhost/AdminLTE-3.0.4/Projects/Join/" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Join Project</p>
                </a>
              </li>
            </ul>
          </li>
		  <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Groups
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
			  <li class="nav-item">
                <a href="../../group/chat/chat.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Groups List</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../group/create/create.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Create Group</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../group/update/update.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Edit Group</p>
                </a>
              </li>
            </ul>
          </li>
		  <li class="nav-item has-treeview">
            <a href="http://localhost/AdminLTE-3.0.4/Group/chat/chat.php" class="nav-link">
              <i class="nav-icon fas fa-comments"></i>
              <p>
                Chat Box
              </p>
            </a>
          </li>
		  <li class="nav-item has-treeview">
            <a href="http://localhost/AdminLTE-3.0.4/Collab_Projects/list" class="nav-link">
              <i class="nav-icon fas fa-tasks"></i>
              <p>
                Collab Projects
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>